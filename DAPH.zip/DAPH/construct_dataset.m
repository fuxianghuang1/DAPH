function [exp_data]=construct_dataset(db_name,param)
addpath('./DB/');
%%choose and load dataset
if strcmp(db_name,'Amazon&Dslr')
     load amazon_fc7 %source data
     Xs = double(fts);
     Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
     ys = labels;
     clear fts; clear labels;

    load dslr_fc7 %target data
    Xt = double(fts);
    Xt = normalize1(Xt);%Xt/max(max(abs(Xt)));
    yt = labels;
   clear fts; clear labels;
   
elseif strcmp(db_name,'Dslr&Amazon')
     load  dslr_fc7%source data
     Xs = double(fts);
     Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
     ys = labels;
     clear fts; clear labels;

    load amazon_fc7 %target data
    Xt = double(fts);
    Xt = normalize1(Xt);%Xt/max(max(abs(Xt)));
    yt = labels;
   clear fts; clear labels;
   
elseif strcmp(db_name,'Amazon&Webcam')
     load  amazon_fc7%source data
     Xs = double(fts);
     Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
     ys = labels;
     clear fts; clear labels;

    load  webcam_fc7%target data
    Xt = double(fts);
    Xt = normalize1(Xt);%Xt/max(max(abs(Xt)));
    yt = labels;
   clear fts; clear labels;
   
elseif strcmp(db_name,'Webcam&Amazon')
     load  webcam_fc7%source data
     Xs = double(fts);
     Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
     ys = labels;
     clear fts; clear labels;

    load  amazon_fc7%target data
    Xt = double(fts);
    Xt = normalize1(Xt);%Xt/max(max(abs(Xt)));
    yt = labels;
   clear fts; clear labels;
elseif strcmp(db_name,'Webcam&Dslr')
     load  webcam_fc7%source data
     Xs = double(fts);
     Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
     ys = labels;
     clear fts; clear labels;

    load  dslr_fc7%target data
    Xt = double(fts);
    Xt = normalize1(Xt);%Xt/max(max(abs(Xt)));
    yt = labels;
   clear fts; clear labels;
 
elseif strcmp(db_name,'Dslr&Webcam')
     load  dslr_fc7%source data
     Xs = double(fts);
     Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
     ys = labels;
     clear fts; clear labels;

    load  webcam_fc7%target data
    Xt = double(fts);
    Xt = normalize1(Xt);%Xt/max(max(abs(Xt)));
    yt = labels;
   clear fts; clear labels;
   
elseif strcmp(db_name,'MNIST&USPS')   
   load MNIST.mat %source data
   Xs = double(fea);
   Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
   ys = double(gnd+1); %vector label
   load USPS.mat
   Xt = double(fea);
   Xt = normalize1(Xt);%Xs/max(max(abs(Xs)));
   yt = double(gnd); %vector label
   clear fea;  clear gnd;
   
elseif strcmp(db_name,'USPS&MNIST')   
   load USPS.mat %source data
   Xs = double(fea);
   Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
   ys = double(gnd); %vector label
   load MNIST.mat
   Xt = double(fea);
   Xt = normalize1(Xt);%Xs/max(max(abs(Xs)));
   yt = double(gnd+1); %vector label
   clear fea;  clear gnd;
    
elseif strcmp(db_name,'COIL1&COIL2')   
   load COIL_1.mat %source data
   Xs = double(X_src)';
   Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
   ys = double(Y_src); %vector label
   Xt = double(X_tar)';
   Xt = normalize1(Xt);%Xs/max(max(abs(Xs)));
   yt = double(Y_tar); %vector label
   clear X_src;  clear Y_src;  clear X_tar;  clear Y_tar;
    
elseif strcmp(db_name,'COIL2&COIL1')   
   load COIL_2.mat %source data
   Xs = double(X_src)';
   Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
   ys = double(Y_src); %vector label
   Xt = double(X_tar)';
   Xt = normalize1(Xt);%Xs/max(max(abs(Xs)));
   yt = double(Y_tar); %vector label
   clear X_src;  clear Y_src;  clear X_tar;  clear Y_tar;

elseif strcmp(db_name,'Clipart&Real')   
   load Clipart_feature_mat %source data
   Xs = double(deepfea);
   Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
   ys = double(label+1)'; %vector label
   clear deepfea; clear label;

   load Real_World_feature_mat %target data
   Xt = double(deepfea);
   Xt = normalize1(Xt);%Xs/max(max(abs(Xs)));
   yt = double(label+1)'; %vector label
   clear deepfea; clear label;

elseif strcmp(db_name,'Real&Clipart')   
   load Real_World_feature_mat %source data
   Xs = double(deepfea);
   Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
   ys = double(label+1)'; %vector label
   clear deepfea; clear label;

   load Clipart_feature_mat %target data
   Xt = double(deepfea);
   Xt = normalize1(Xt);%Xs/max(max(abs(Xs)));
   yt = double(label+1)'; %vector label
   clear deepfea; clear label;

elseif strcmp(db_name,'Product&Real')   
   load Product_feature_mat %source data
   Xs = double(deepfea);
   Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
   ys = double(label+1)'; %vector label
   clear deepfea; clear label;

   load Real_World_feature_mat %target data
   Xt = double(deepfea);
   Xt = normalize1(Xt);%Xs/max(max(abs(Xs)));
   yt = double(label+1)'; %vector label
   clear deepfea; clear label; 

elseif strcmp(db_name,'Real&Product')   
   load Real_World_feature_mat %source data
   Xs = double(deepfea);
   Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
   ys = double(label+1)'; %vector label
   clear deepfea; clear label;

   load Product_feature_mat %target data
   Xt = double(deepfea);
   Xt = normalize1(Xt);%Xs/max(max(abs(Xs)));
   yt = double(label+1)'; %vector label
  clear deepfea; clear label;

elseif strcmp(db_name,'Art&Real')   
   load Art_feature_mat %source data
   Xs = double(deepfea);
   Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
   ys = double(label+1)'; %vector label
   clear deepfea; clear label;

   load Real_World_feature_mat %target data
   Xt = double(deepfea);
   Xt = normalize1(Xt);%Xs/max(max(abs(Xs)));
   yt = double(label+1)'; %vector label
   clear deepfea; clear label;

elseif strcmp(db_name,'Real&Art')   
   load Real_World_feature_mat %source data
   Xs = double(deepfea);
   Xs = normalize1(Xs);%Xs/max(max(abs(Xs)));
   ys = double(label+1)'; %vector label
   clear deepfea; clear label;

   load Art_feature_mat%target data
   Xt = double(deepfea);
   Xt = normalize1(Xt);%Xs/max(max(abs(Xs)));
   yt = double(label+1)'; %vector label
clear deepfea; clear label;       
end

[ndatat,~]      =     size(Xt);
R               =     randperm(ndatat);
exp_data.R      =   R;
num_test        =  round(0.1*ndatat);
test            =     Xt(R(1:num_test),:);
ytest           =     yt(R(1:num_test));
R(1:num_test)   =     [];
train           =     Xt(R,:);
train_ID = R;
Yt  =yt;
yt              =     yt(R);

if strcmp(param.retrieval, 'cross-domain')
 YS            =  repmat(ys,1,length(ytest));
 YT            =  repmat(ytest,1,length(ys));
elseif strcmp(param.retrieval, 'single-domain')
 YS            =  repmat(yt,1,length(ytest));
 YT            =  repmat(ytest,1,length(yt));
end

WTT           =  (YT==YS');

X=[Xs;Xt];
samplemean              = mean(X,1);
Xs                      = Xs-repmat(samplemean,size(Xs,1),1);
train                   = train-repmat(samplemean,size(train,1),1);
test                    = test-repmat(samplemean,size(test,1),1);


exp_data.num_test   = num_test;
exp_data.Xs         =   Xs ;
exp_data.train_ID   = train_ID;
exp_data.test       =   test;
exp_data.train      =   train;
exp_data.ys         =   ys ;
exp_data.yt         =   yt ;
exp_data.Yt         =   Yt ;
exp_data.train_all  =   [Xs;train];
exp_data.WTT           =WTT ;
end
