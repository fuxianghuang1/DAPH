function [B_trn,B_tst]=trainDAPH1(exp_data,param)
Xs                =    exp_data.Xs;
Xt                =    exp_data.train;
test              =    exp_data.test;
Ys                =    exp_data.ys;
%% set parameters
setting.record = 0; %
setting.mxitr  = 5;
setting.xtol = 1e-5;
setting.gtol = 1e-5;
setting.ftol = 1e-8;
paras.lambda0    =   1;
paras.lambda1    =   1e-2;
paras.lambda2    =   1;
paras.lambda3    =   1e3; 
paras.max_iter   = 5;

[paras.nt,paras.d] =   size(Xt);
[paras.ns,paras.d] =   size(Xs);
%% leraning
YS          =  repmat(Ys,1,length(Ys));
S           =  (YS==YS');
D           =  diag(sum(S, 2));
L           =  D - S;
paras.LXs   = 1* Xs'*L*Xs;
X=[Xs;Xt];
Ms              = mean(Xs,1);
Mt              = mean(Xt,1);
Mst             = (Ms-Mt)';
M               = mean(X,1);
X1=(X-M)';

[vec,val]  =   eig(X1*X1');
[~,Idx]      =   sort(diag(val),'descend');
PCA          =   vec(:,Idx(1:param.r));
clear Idx;clear vec; clear val;

X =  X';
B  = sign(PCA'*X1);
W = randn(param.r, param.r);
[U S0 V0] = svd(W);
W = U(:, 1:param.r);
G = eye(paras.d);
P=PCA;
for iter=1:paras.max_iter

    [P, ~]        = OptStiefelGBB(P, @P_obj1, setting,Mst,X1,X,B,W,paras);
    Z=X'*P;
    C=B*Z;
    [UB, sigma, UA] = svd(C);    
    W = UA * UB';
    B            = sign(W'*P'*X1);
end 


if strcmp(param.retrieval, 'cross-domain')
 B_train           =    (Xs*P*W>0);
elseif strcmp(param.retrieval, 'single-domain')
 B_train           =    (Xt*P*W>0);
end

B_test            =    (test*P*W>0);
B_trn             =    compactbit(B_train);
B_tst             =    compactbit(B_test);
end