function [recall, precision, mAP, rec, pre, retrieved_list] = demo(exp_data, param, method)
ID.train = exp_data.train_ID;
WtrueTestTraining = exp_data.WTT ;
pos               = param.pos;
%several state of art methods
if strcmp(param.retrieval, 'cross-domain')  
  switch(method)
    %% method proposed
        case 'DAPH' 
        addpath('./Method-DAPH/');
	    fprintf('......%s start ......\n\n', 'DAPH');
          tic
        [B_trn,B_tst]=trainDAPH(exp_data,param);
        toc
        fprintf('Train in %.3fs\n', toc);
        
        case 'DAPH*' 
        addpath('./Method-DAPH1/');
	    fprintf('......%s start ......\n\n', 'DAPH*');
          tic
        [B_trn,B_tst]=trainDAPH1(exp_data,param);
        toc
        fprintf('Train in %.3fs\n', toc);
  end

elseif strcmp(param.retrieval, 'single-domain')
  switch(method)
    %% method proposed

        case 'DAPH'  
        addpath('./Method-DAPH/');
	    fprintf('......%s start ......\n\n', 'DAPH');
          tic
        [B_trn,B_tst]=trainDAPH(exp_data,param);
        toc
        fprintf('Train in %.3fs\n', toc);
        
        case 'DAPH*'  
        addpath('./Method-DAPH1/');
	    fprintf('......%s start ......\n\n', 'DAPH*');
          tic
        [B_trn,B_tst]=trainDAPH1(exp_data,param);
        toc
        fprintf('Train in %.3fs\n', toc);
  end
end
% compute Hamming metric and compute recall precision
Dhamm = hammingDist(B_tst, B_trn);
[~, rank] = sort(Dhamm, 2, 'ascend');
clear B_tst B_trn;
choice = param.choice;
switch(choice)
    case 'evaluation_PR_MAP'
        clear train_data test_data;
        [recall, precision, ~] = recall_precision(WtrueTestTraining, Dhamm);
	[rec, pre]= recall_precision5(WtrueTestTraining, Dhamm, pos); % recall VS. the number of retrieved sample
        [mAP] = area_RP(recall, precision);
        retrieved_list = [];
    case 'evaluation_PR'
        clear train_data test_data;
        eva_info = eva_ranking(rank, trueRank, pos);
        rec = eva_info.recall;
        pre = eva_info.precision;
        recall = [];
        precision = [];
        mAP = [];
        retrieved_list = [];
    case 'visualization'
        num = param.numRetrieval;
        retrieved_list =  visualization(Dhamm, ID, num, train_data, test_data); 
        recall = [];
        precision = [];
        rec = [];
        pre = [];
        mAP = [];
end

end
