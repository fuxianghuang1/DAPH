function [ F, G] = P_obj(P,Mst,X1,X,B,W,paras)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
F       = trace(P'*(Mst*Mst'-paras.lambda1*(X1*X1')+paras.lambda3)*P)+paras.lambda2*norm(B-W'*P'*X,'fro')^2;
G       = (paras.lambda0*(Mst*Mst')-paras.lambda1*(X1*X1')+paras.lambda2*(X*X')+paras.lambda3)*P-(paras.lambda2*X*B'*W');
end

